Easy Thumbnails 2.8
===================

Introduction
------------
Easy Thumbnails is a handy freeware utility for creating accurate
thumbnail images and scaled-down/up copies from a wide range of
popular picture formats. An elegant interface makes it a snap to
find your images and select them for processing individually, in
groups, or in whole folders, using a simple file selector and
built-in image viewer. You can use slider controls to rotate
images and adjust their contrast, brightness, sharpness and
quality, and check out the results with a convenient built-in
viewer.

Thumbnails can be created in any existing folder or a new folder,
and you can identify them clearly by adding a prefix or suffix to
their titles. If you're an image-processing enthusiast, you'll
enjoy having a choice of nine resampling algorithms for the
best possible results. You can convert small batches of images
inside Windows Explorer from the File menu or with a right-click
of the mouse, display thumbnails in your browser, and even take
advantage of command-line switches to generate thumbnails
seamlessly from other programs. You can also save your thumbnails
to a Web page using a HTML template that you can easily customize
to create your own layouts, and there's helpful documentation
that includes full instructions and some useful tips.

Easy Thumbnails is a genuine freeware product that will not annoy
you with advertising, intrusive spyware components or nag screens.
It comes from Fookes Software, developers of the award-winning
NoteTab text editors and other high-quality applications.

You'll find updates and other great software at our Web site...
http://www.fookes.com/


Installation
------------
Extract the Setup.exe file from the .zip package, execute it, and
follow the instructions.

Under Windows NT, 2000, and XP, the Setup program will only be
able to add the Windows Explorer "Make Thumbnail" menu shortcut
if you have the appropriate access privileges.

System Requirements
...................
- Windows 95/98/2000/NT4/ME/XP
- 1.4 MB of free disk space
- 16 MB of RAM (32 MB for NT)

How to Uninstall
................
You can uninstall Easy Thumbnails by using the Control Panel's
Add/Remove Programs dialog box or the Uninstall Easy Thumbnails
icon in the Start menu.


License
-------
Fookes Software grants you a free license to use Easy Thumbnails
on as many desktop/laptop computers as you wish. However, the
following types of usage require that you purchase a license from
Fookes Software (contact <sales@fookes.com> for details):

* Bundling Easy Thumbnails with a software or hardware product.
* Running Easy Thumbnails from a network server.
* Running Easy Thumbnails on a server as a process for another
  application.


Feedback
--------
Bug reports, criticism, praise, and comments are very welcome.
You can send these to <feedback@fookes.com>.


I hope you will find Easy Thumbnails useful. Do tell others about
our software. The more successful it becomes, the more we will be
encouraged to continue developing software of this nature.

--Eric G.V. Fookes
Developer and founder of Fookes Software

_________________________________________________________________
 Easy Thumbnails� is a trademark of Fookes Software, Switzerland
       Copyright � 2001-2004, Fookes Software, Switzerland
                     - All Rights Reserved -

Windows is a trademark of Microsoft Corporation registered in the
  U.S. and other countries.  
All other trademarks and service marks are the property of their
  respective owners.
